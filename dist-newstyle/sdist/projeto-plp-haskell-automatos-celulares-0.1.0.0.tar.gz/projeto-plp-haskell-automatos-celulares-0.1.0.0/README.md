# projeto-plp-haskell-automatos-celulares
